<?php /**
 * Plugin Name: WooCommerce GeoAddress Checker
 * Description: Will use GeoAddress Checker to verify the address entered in the checkout
 * Author: Matrix Internet
 * Author URI: https://www.matrixinternet.ie
 * Version: 1.0
 */

function geoaddresschecker_settings_link($links) { 
    $settings_link = '<a href="admin.php?page=wc-settings&tab=settings_tab_geoaddresschecker">Settings</a>'; 
    array_unshift($links, $settings_link); 
    return $links; 
}
$plugin = plugin_basename(__FILE__); 
add_filter("plugin_action_links_$plugin", 'geoaddresschecker_settings_link' );

/**
 * Register the "book" custom post type
 */
function geoadresschecker_pluginprefix_setup_post_type() {
    // register_post_type('book', ['public' => true ]); 
} 
add_action('init', 'geoadresschecker_pluginprefix_setup_post_type');
 
 
/**
 * Activate the plugin.
 */
function geoadresschecker_pluginprefix_activate() { 
    // Trigger our function that registers the custom post type plugin.
    // pluginprefix_setup_post_type(); 
    // Clear the permalinks after the post type has been registered.
    // flush_rewrite_rules(); 
}
register_activation_hook(__FILE__, 'geoadresschecker_pluginprefix_activate');


/**
 * Deactivation hook.
 */
function geoadresschecker_pluginprefix_deactivate() {
    // Unregister the post type, so the rules are no longer in memory.
    // unregister_post_type('book');
    // Clear the permalinks to remove our post type's rules from the database.
    // flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'geoadresschecker_pluginprefix_deactivate');


/**
* Create the section beneath the products tab
**/

class WC_Settings_GeoAddressChecker {

    /**
     * Bootstraps the class and hooks required actions & filters.
     *
     */
    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_settings_tab_geoaddresschecker', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_settings_tab_geoaddresschecker', __CLASS__ . '::update_settings' );
    }
    
    
    /**
     * Add a new settings tab to the WooCommerce settings tabs array.
     *
     * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
     * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
     */
    public static function add_settings_tab( $settings_tabs ) {
        $settings_tabs['settings_tab_geoaddresschecker'] = __( 'Geo Address Checker', 'geoaddresschecker_plugin' );
        return $settings_tabs;
    }


    /**
     * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
     *
     * @uses woocommerce_admin_fields()
     * @uses self::get_settings()
     */
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }


    /**
     * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
     *
     * @uses woocommerce_update_options()
     * @uses self::get_settings()
     */
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }


    /**
     * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
     *
     * @return array Array of settings for @see woocommerce_admin_fields() function.
     */
    public static function get_settings() {

        $settings = array(
            'section_title' => array(
                'name'     => __( 'Geo Address Checker', 'geoaddresschecker_plugin' ),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'wc_settings_GeoAddressChecker_section_title'
            ),
            'token' => array(
                'name' => __( 'Token', 'geoaddresschecker_plugin' ),
                'type' => 'text',
                'desc' => '<a href="https://www.geoaddress-checked.ie/tokens" target="_blank">'.__( 'Click here', 'geoaddresschecker_plugin' ).'</a> '.__( 'to get a token.', 'geoaddresschecker_plugin' ),
                'id'   => 'wc_settings_GeoAddressChecker_token'
            ),
            //'description' => array(
            //    'name' => __( 'Description', 'geoaddresschecker_plugin' ),
            //    'type' => 'textarea',
            //    'desc' => __( 'This is a paragraph describing the setting. Lorem ipsum yadda yadda yadda. Lorem ipsum yadda yadda yadda. Lorem ipsum yadda yadda yadda. Lorem ipsum yadda yadda yadda.', 'geoaddresschecker_plugin' ),
            //    'id'   => 'wc_settings_GeoAddressChecker_description'
            //),
            'section_end' => array(
                 'type' => 'sectionend',
                 'id' => 'wc_settings_GeoAddressChecker_section_end'
            )
        );

        return apply_filters( 'wc_settings_GeoAddressChecker_settings', $settings );
    }

}

WC_Settings_GeoAddressChecker::init();

/**
 * @param array      $array
 * @param int|string $position
 * @param mixed      $insert
 */
function geoadresschecker_array_insert(&$array, $position, $insert) {
    if (is_int($position)) {
        array_splice($array, $position, 0, $insert);
    } else {
        $pos   = array_search($position, array_keys($array));
        $array = array_merge(
            array_slice($array, 0, $pos),
            $insert,
            array_slice($array, $pos)
        );
    }
}

function geoadresschecker_show_error_banner() {
    return '<div class="notice alert">
                '.__( 'The Geo Address Checker will not work as you haven\'t added a correct token. Please go to the ', 'geoaddresschecker_plugin')
                .'<a href="'.get_bloginfo('url').'/wp-admin/admin.php?page=wc-settings&tab=settings_tab_geoaddresschecker">'
                .__( 'plugin admin', 'geoaddresschecker_plugin')
                .'</a>'
                .__( ' to add or correct it', 'geoaddresschecker_plugin')
            .'</div>';
}



function geoaddresschecker_script() {

    $wc_settings_GeoAddressChecker_token = get_option('wc_settings_GeoAddressChecker_token');
    
    if(is_checkout() || is_wc_endpoint_url('edit-address')) {

        wp_enqueue_style('geoaddresschecker_frontend_css', plugin_dir_url(__FILE__).'css/frontend.css');

        if($wc_settings_GeoAddressChecker_token) {
            
            wp_enqueue_script('geoaddresschecker_frontend_js', plugins_url( 'js/frontend.js', __FILE__ ), array('jquery'));
            $template_url = get_bloginfo('template_url');
            wp_localize_script('geoaddresschecker_frontend_js', '$wc_settings_GeoAddressChecker_token', $wc_settings_GeoAddressChecker_token);

            wp_localize_script('geoaddresschecker_frontend_js', '$empty_notice', __('Sorry, there are no result', 'woocommerce'));


            

        } elseif(current_user_can('manage_options')) {
            echo geoadresschecker_show_error_banner();
        }
    }

}
add_action('wp_enqueue_scripts', 'geoaddresschecker_script');


// Insert the geoaddresschecker field before the address field
function geoadresschecker_override_checkout_fields($fields) {

    if(get_option('wc_settings_GeoAddressChecker_token')) {

        $billing_geoaddresschecker['billing_geoaddresschecker'] = array(
            'label'     => __('Address Lookup', 'woocommerce'),
            'placeholder'   => _x('Start typing', 'placeholder', 'woocommerce'),
            'required'  => false,
            'class'     => array('form-row-wide geoaddresschecker'),
            'clear'     => true
        );

        geoadresschecker_array_insert(
            $fields['billing'],
            'billing_address_1',
            $billing_geoaddresschecker
        );

        $shipping_geoaddresschecker['shipping_geoaddresschecker'] = array(
            'label'     => __('Address Lookup', 'woocommerce'),
            'placeholder'   => _x('Start typing', 'placeholder', 'woocommerce'),
            'required'  => false,
            'class'     => array('form-row-wide geoaddresschecker'),
            'clear'     => true
        );

        geoadresschecker_array_insert(
            $fields['shipping'],
            'shipping_address_1',
            $shipping_geoaddresschecker
        );

       $fields['billing']['billing_address_1']['class'][] = 'address_1';
       $fields['billing']['billing_address_2']['class'][] = 'address_2';
       $fields['billing']['billing_city']['class'][] = 'city';
       $fields['billing']['billing_state']['class'][] = 'state';

       $fields['shipping']['shipping_address_1']['class'][] = 'address_1';
       $fields['shipping']['shipping_address_2']['class'][] = 'address_2';
       $fields['shipping']['shipping_city']['class'][] = 'city';
       $fields['shipping']['shipping_state']['class'][] = 'state';
                      

        // print_rr($fields);        
    }
    return $fields;

}
add_filter('woocommerce_checkout_fields', 'geoadresschecker_override_checkout_fields');


function geoadresschecker_override_address_fields($fields) {

    $billing_geoaddresschecker['geoaddresschecker'] = array(
        'label'     => __('Address Lookup', 'woocommerce'),
        'placeholder'   => _x('Start typing', 'placeholder', 'woocommerce'),
        'required'  => false,
        'class'     => array('form-row-wide geoaddresschecker'),
        'clear'     => true
    );

    geoadresschecker_array_insert(
        $fields,
        'address_1',
        $billing_geoaddresschecker
    );

    $fields['address_1']['class'][] = 'address_1';
    $fields['address_2']['class'][] = 'address_2';
    $fields['city']['class'][] = 'city';
    $fields['state']['class'][] = 'state';

    return $fields;
}
add_filter('woocommerce_default_address_fields', 'geoadresschecker_override_address_fields', 20, 1);




function geoadresschecker_remove_css_js_version($src) {
    if(strpos($src, '?ver='))
        $src = remove_query_arg('ver', $src);
    return $src;
}
add_filter('style_loader_src', 'geoadresschecker_remove_css_js_version', 9999);
add_filter('script_loader_src', 'geoadresschecker_remove_css_js_version', 9999);

/*
require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'http://charlotte.matrix-test.com/matrix-geoadresschecker/matrix-geoadresschecker.json',
    __FILE__, //Full path to the main plugin file or functions.php.
    'matrix-geoadresschecker'
);
*/