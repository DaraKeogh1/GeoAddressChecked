jQuery(document).ready(function($) {


	// Disable address fields
	// $('.woocommerce-billing-fields input[name="billing_address_1"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_address_2"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_city"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_state"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_postcode"]').prop('disabled', true);

	// $('.woocommerce-shipping-fields input[name="shipping_address_1"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_address_2"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_city"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_state"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_postcode"]').prop('disabled', true);

	console.log($wc_settings_GeoAddressChecker_token);

	// Show only if country is Ireland
	// $(this).parents('div').find('.country_select').val() == 'IE')	

	function capitalize(str) {
		return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
	}

	function show_hide_geoaddresscheck($this) {

		if($this.val() == 'IE') {
			$this.parent().closest('div').find('.geoaddresschecker').show();			
		} else {
			$this.parent().closest('div').find('.geoaddresschecker').hide();
		}
	}

	function get_county_code($county_name) {

		var $counties = {};

		$counties['Carlow'] = 'CW';
		$counties['Cavan'] = 'CN';
		$counties['Clare'] = 'CE';
		$counties['Cork'] = 'CO';
		$counties['Donegal'] = 'DL';
		$counties['Dublin'] = 'D';
		$counties['Galway'] = 'G';
		$counties['Kerry'] = 'KY';
		$counties['Kildare'] = 'KE';
		$counties['Kilkenny'] = 'KK';
		$counties['Laois'] = 'LS';
		$counties['Leitrim'] = 'LM';
		$counties['Limerick'] = 'LK';
		$counties['Longford'] = 'LD';
		$counties['Louth'] = 'LH';
		$counties['Mayo'] = 'MO';
		$counties['Meath'] = 'MH';
		$counties['Monaghan'] = 'MN';
		$counties['Offaly'] = 'OY';
		$counties['Roscommon'] = 'RN';
		$counties['Sligo'] = 'SO';
		$counties['Tipperary'] = 'TA';
		$counties['Waterford'] = 'WD';
		$counties['Westmeath'] = 'WH';
		$counties['Wexford'] = 'WX';
		$counties['Wicklow'] = 'WW';

		return $counties[$county_name];
	}	

	$('.country_select').each(function() {
		
		console.log('init');
		show_hide_geoaddresscheck($(this));

	});

	$('.country_select').change(function() {
		console.log('change');
		show_hide_geoaddresscheck($(this));

	});

	// Init the search container
	$('.geoaddresschecker input').click(function() {		

		if($(this).parents('.geoaddresschecker').find('.results').length == 0) {
			$(this).parents('.geoaddresschecker').append('<ul class="results loading"></ul>');
		}

		if($(this).val().length > 2) {	

			geoaddresschecker_ajax($(this), $(this).val());
			
		}

	});

	function geoaddresschecker_ajax($this, $search) {

		var $container = $this.parents('.geoaddresschecker').find('.results');

		$.ajax({
			type: "POST",
			url: "https://www.geoaddress-checked.ie/api/dev/v1/search-address",
			data: JSON.stringify({
				q: $search
			}),
			headers: {
				"content-type": "application/json",
				"authorization": "Bearer " + $wc_settings_GeoAddressChecker_token
			},
			success: function(data) {
				console.log(data.results);
				$container.removeClass('loading');		
				$container.empty();		
				if($(data.results).length == 0) {

					$container.append('<li class="result empty">'+$empty_notice+'</li>');

				} else {
					
					$(data.results).each(function($key, $object) {		
						var $return = '';
						var $attr = '';		
						$.each($object, function($key, $value) {

							if($value && $key != 'identification') {

								$value = $value.toLowerCase();
								// $value_capitalized = $value.charAt(0).toUpperCase() + $value.slice(1);
								$value_capitalized = capitalize($value);

								// console.log('key => '+$key+ ' | value => '+$value);
								$return = $return.concat($value_capitalized+' ');
								$attr = $attr.concat('data-'+$key+'="'+$value_capitalized+'" ');
							}

						});

						$container.append('<li class="result success" '+$attr+'>'+$return+'</li>');						
						// console.log($attr);
						// console.log($return);
					});
				}
			}
		});
	}
	
	$('.geoaddresschecker input').keyup(function() {		

		if($(this).val().length > 2) {			

			geoaddresschecker_ajax($(this), $(this).val());
			
		}
	});

	$('body').click(function(evt){    
		if(evt.target.id == "billing_geoaddresschecker_field" || evt.target.id == "shipping_geoaddresschecker_field")
			return;
	
		if($(evt.target).closest('#billing_geoaddresschecker_field').length || $(evt.target).closest('#shipping_geoaddresschecker_field').length){
			return;
		}   

		$('.geoaddresschecker .results').remove();		
   
	});

	$(document).on('click', '.geoaddresschecker .result', function() {		

		var $parent = $(this).parent().closest('div');

		$parent.find('.address_1 input').val($(this).data('addr_1'));
		$parent.find('.city input').val($(this).data('addr_2'));

		if($(this).data('addr_3')) {
			$county_code = get_county_code($(this).data('addr_3'));
			console.log($(this).data('addr_3'));
			console.log($county_code);

			$parent.find('.state_select').val($county_code).trigger('change');
		} else {
			$parent.find('.state_select').val(0).trigger('change');
		}
		
		$parent.find('.geoaddresschecker .results').remove();
		$parent.find('.geoaddresschecker input').val($(this).text());

	});	

});