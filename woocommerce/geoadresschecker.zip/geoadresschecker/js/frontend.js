jQuery(document).ready(function($) {


	// Disable address fields
	// $('.woocommerce-billing-fields input[name="billing_address_1"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_address_2"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_city"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_state"]').prop('disabled', true);
	// $('.woocommerce-billing-fields input[name="billing_postcode"]').prop('disabled', true);

	// $('.woocommerce-shipping-fields input[name="shipping_address_1"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_address_2"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_city"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_state"]').prop('disabled', true);
	// $('.woocommerce-shipping-fields input[name="shipping_postcode"]').prop('disabled', true);

	// console.log($wc_settings_GeoAddressChecker_token);

	// Show only if country is Ireland
	// $(this).parents('div').find('.country_select').val() == 'IE')

	function capitalize(str) {
		return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
	}

	function show_hide_geoaddresscheck($this) {

		if($this.val() == 'IE') {
			$this.parent().closest('div').find('.geoaddresschecker').show();
		} else {
			$this.parent().closest('div').find('.geoaddresschecker').hide();
		}
	}

	function get_county_code($county_name) {

		var $counties = {};

		$counties['Carlow'] = 'CW';
		$counties['Cavan'] = 'CN';
		$counties['Clare'] = 'CE';
		$counties['Cork'] = 'CO';
		$counties['Donegal'] = 'DL';
		$counties['Dublin'] = 'D';
		$counties['Galway'] = 'G';
		$counties['Kerry'] = 'KY';
		$counties['Kildare'] = 'KE';
		$counties['Kilkenny'] = 'KK';
		$counties['Laois'] = 'LS';
		$counties['Leitrim'] = 'LM';
		$counties['Limerick'] = 'LK';
		$counties['Longford'] = 'LD';
		$counties['Louth'] = 'LH';
		$counties['Mayo'] = 'MO';
		$counties['Meath'] = 'MH';
		$counties['Monaghan'] = 'MN';
		$counties['Offaly'] = 'OY';
		$counties['Roscommon'] = 'RN';
		$counties['Sligo'] = 'SO';
		$counties['Tipperary'] = 'TA';
		$counties['Waterford'] = 'WD';
		$counties['Westmeath'] = 'WH';
		$counties['Wexford'] = 'WX';
		$counties['Wicklow'] = 'WW';

		if($county_name.includes('Dublin')) {
			return 'D';
		}

		return $counties[$county_name];
	}

	$('.country_select').each(function() {
		show_hide_geoaddresscheck($(this));
	});

	$('.country_select').change(function() {
		show_hide_geoaddresscheck($(this));
	});
	
	if($('#billing_country').val() == 'IE') {
		$('#billing_country').parent().closest('div').find('.geoaddresschecker').show();
	}

	if($('#shipping_country').val() == 'IE') {
		$('#shipping_country').parent().closest('div').find('.geoaddresschecker').show();
	}

	// Init the search container
	$('.geoaddresschecker input').click(function() {

		if($(this).parents('.geoaddresschecker').find('.results').length == 0) {
			$(this).parents('.geoaddresschecker').append('<ul class="results loading"></ul>');
		}

		if($(this).val().length > 2) {

			geoaddresschecker_ajax($(this), $(this).val());

		}

	});

	function geoaddresschecker_ajax($this, $search) {

		var $container = $this.parents('.geoaddresschecker').find('.results');

		$.ajax({
			type: "POST",
			url: "https://www.geoaddress-checked.ie/api/v1/search-address",
			data: JSON.stringify({
				q: $search
			}),
			headers: {
				"content-type": "application/json",
				"authorization": "Bearer " + $wc_settings_GeoAddressChecker_token
			},
			success: function(data) {
				// console.log(data.results);
				$container.removeClass('loading');
				$container.empty();
				if($(data.results).length == 0) {

					$container.append('<li class="result empty">'+$empty_notice+'</li>');

				} else {

					$(data.results).each(function($key, $object) {
						var $return = '';
						var $attr = '';
						$.each($object, function($key, $value) {

							if($value && $key != 'identification') {

								$value = $value.toLowerCase();
								// $value_capitalized = $value.charAt(0).toUpperCase() + $value.slice(1);
								$value_capitalized = capitalize($value);

								// console.log('key => '+$key+ ' | value => '+$value);
								$return = $return.concat($value_capitalized+' ');
								$attr = $attr.concat('data-'+$key+'="'+$value_capitalized+'" ');
							}

							if($value && $key == 'identification') {
								$id = $value;
							}

						});

						$container.append('<li id="'+$id+'" class="result success" '+$attr+'>'+$return+'</li>');
						// console.log($attr);
						// console.log($return);
					});
				}
			}
		});
	}

	$('.geoaddresschecker input').keyup(function() {

		if($(this).val().length > 2) {

			geoaddresschecker_ajax($(this), $(this).val());

		}
	});

	$('body').click(function(evt){
		if(evt.target.id == "billing_geoaddresschecker_field" || evt.target.id == "shipping_geoaddresschecker_field")
			return;

		if($(evt.target).closest('#billing_geoaddresschecker_field').length || $(evt.target).closest('#shipping_geoaddresschecker_field').length){
			return;
		}

		$('.geoaddresschecker .results').remove();

	});

	$(document).on('click', '.geoaddresschecker .result', function() {

		var $parent = $(this).parent().closest('div');

		// Get details on address
		$.ajax({
			type: "POST",
			url: "https://www.geoaddress-checked.ie/api/v1/search-identification",
			data: JSON.stringify({identification: $(this).attr('id')}),
			headers: {
				"content-type": "application/json",
				"authorization": "Bearer " + $wc_settings_GeoAddressChecker_token
			},
			success: function(data) {
				var $result = data.results;
				var $latest = 0;



				for (let i = 1; i < 11; i++) {
					var $label = 'addr_'+i;					
					if(!$result[$label]) {
						$latest = parseInt(i-1);
						break;
					} else {

						$format = $result[$label].toLowerCase();
						$format = capitalize($format);

						$result[$label] = $format;
					}
				}

				// Fix for Dublin which doesn't include the city
				if($result['addr_'+$latest].includes('Dublin')) {
					$result['addr_'+parseInt($latest+1)] = 'Dublin';
					$latest = parseInt($latest+1);
				}

				var $return = {};
				$return.eircode = $result['eircode'];
				$return.street = $result['addr_1'];
				$return.street2 = '';
				$return.city = $result['addr_2'];
				$return.county = $result['addr_2'];

				if($latest == 3) {
					$return.county = $result['addr_3'];
				}

				if($latest == 4) {
					$return.street = $result['addr_2'];
					$return.county = $result['addr_4'];
				}

				if($latest > 4) {

					$county_label = 'addr_'+$latest;
					$return.county = $result[$county_label];

					$city_label = 'addr_'+parseInt($latest-1);
					$return.city = $result[$city_label];

					$street_count = parseInt($latest-2);
					for (let i = 2; i <= $street_count; i++) {

						$label = 'addr_'+i;
						$addr = $result[$label]
						$return.street2 = $return.street2.concat($addr+' ');

					}
				}

				// Fix for Dublin city
				if($return['city'].includes('Dublin')) {
					$return['city'] = 'Dublin';
				}

				$return.countycode = get_county_code($return.county);
				// console.log($return);

				$parent.find('.address_1 input').val($return.street);
				$parent.find('.address_2 input').val($return.street2);
				$parent.find('.city input').val($return.city);
				$parent.find('.state_select').val($return.countycode).trigger('change');
				$parent.find('.eircode input').val($return.eircode);
				

				
				$parent.find('.geoaddresschecker .results').remove();
				$parent.find('.geoaddresschecker input').val($(this).text());
			}
		});
		
		/*
		var $parent = $(this).parent().closest('div');

		$parent.find('.address_1 input').val($(this).data('addr_1'));
		$parent.find('.city input').val($(this).data('addr_2'));

		if($(this).data('addr_4')) {
			$county_code = get_county_code($(this).data('addr_4'));
			$parent.find('.state_select').val($county_code).trigger('change');
		} else {

			if($(this).data('addr_3')) {
				$county_code = get_county_code($(this).data('addr_3'));
				$parent.find('.state_select').val($county_code).trigger('change');

			} else {	
				$parent.find('.state_select').val(0).trigger('change');
			}
		}
		*/

	});

});
